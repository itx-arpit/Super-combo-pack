OPEN BOT_CONFIG.txt
Put your NEW BotFather token after BOT_TOKEN=
Example: BOT_TOKEN=PASTE_TOKEN_HERE
Do NOT share the token with anyone.
