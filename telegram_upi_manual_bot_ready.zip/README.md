# Telegram UPI Manual-Verification Selling Bot

## What it does
User:
1. `/start`
2. Taps Buy
3. Sees your UPI QR + UPI ID
4. Pays exactly the shown amount
5. Taps "I Have Paid"
6. Sends UTR / transaction reference

Admin:
1. Receives order + UTR in Telegram
2. Checks the payment in the bank/UPI app
3. Presses Approve or Reject
4. On Approve, the bot automatically sends `files/study_pack.zip`

## Setup
### 1) BotFather
- Open Telegram and search `@BotFather`.
- Send `/newbot`.
- Choose a name, e.g. `Target Study Pack`.
- Choose a username ending in `bot`, e.g. `Target116StudyBot` if available.
- BotFather gives a token. Put it in `.env` as `BOT_TOKEN`.

### 2) Find your numeric Telegram ID
Use a trusted Telegram ID bot such as `@userinfobot`, or another method you already trust.
Put the numeric ID in `ADMIN_ID`.

### 3) Add your UPI details
In `.env`:
UPI_ID=yourupi@bank
PRICE_INR=50
SUPPORT_USERNAME=@Target116

### 4) Add QR
Save your UPI QR image as:
files/upi_qr.png

### 5) Add your product file
Save your own/licensed material ZIP as:
files/study_pack.zip

### 6) Install and run
pip install -r requirements.txt
python bot.py

For a 24/7 bot, run this on a server/VPS with Python 3.11+.

## Security
Never publish BOT_TOKEN or give it to anyone.
Only sell/distribute material that you own or are authorized to distribute.
Manual UPI verification is used because a static QR cannot by itself prove a payment to the bot.
