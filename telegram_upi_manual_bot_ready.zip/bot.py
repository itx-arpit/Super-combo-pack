import os
import sqlite3
from pathlib import Path

from aiogram import Bot, Dispatcher, Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import (
    Message, CallbackQuery, FSInputFile,
    InlineKeyboardMarkup, InlineKeyboardButton
)
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
UPI_ID = os.getenv("UPI_ID", "yourupi@bank").strip()
PRICE = int(os.getenv("PRICE_INR", "50"))
PRODUCT_NAME = os.getenv("PRODUCT_NAME", "JEE Premium Study Pack")
DELIVERY_FILE = Path(os.getenv("DELIVERY_FILE", "files/study_pack.zip"))
QR_FILE = Path(os.getenv("QR_FILE", "files/upi_qr.png"))
SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME", "@Target116").strip()

if not BOT_TOKEN or not ADMIN_ID:
    raise RuntimeError("BOT_TOKEN and ADMIN_ID are required")

bot = Bot(BOT_TOKEN)
dp = Dispatcher()
router = Router()
dp.include_router(router)
DB = "orders.db"


def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with conn() as c:
        c.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            order_id TEXT PRIMARY KEY,
            telegram_id INTEGER NOT NULL,
            username TEXT,
            status TEXT NOT NULL,
            utr TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        """)
        c.commit()


def create_order(user_id, username):
    import secrets
    order_id = "JEE-" + secrets.token_hex(4).upper()
    with conn() as c:
        c.execute(
            "INSERT INTO orders(order_id,telegram_id,username,status) VALUES(?,?,?,?)",
            (order_id, user_id, username, "awaiting_payment")
        )
        c.commit()
    return order_id


def get_order(order_id):
    with conn() as c:
        return c.execute(
            "SELECT * FROM orders WHERE order_id=?", (order_id,)
        ).fetchone()


def get_latest_pending(user_id):
    with conn() as c:
        return c.execute(
            """SELECT * FROM orders
               WHERE telegram_id=? AND status IN ('awaiting_payment','submitted')
               ORDER BY created_at DESC LIMIT 1""",
            (user_id,)
        ).fetchone()


def set_utr(order_id, utr):
    with conn() as c:
        c.execute(
            "UPDATE orders SET utr=?, status='submitted' WHERE order_id=?",
            (utr, order_id)
        )
        c.commit()


def set_status(order_id, status):
    with conn() as c:
        c.execute(
            "UPDATE orders SET status=? WHERE order_id=?",
            (status, order_id)
        )
        c.commit()


def user_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"💳 Buy for ₹{PRICE}", callback_data="buy")],
        [InlineKeyboardButton(text="📦 What's Included?", callback_data="details")],
        [InlineKeyboardButton(text="🆘 Support", url=f"https://t.me/{SUPPORT_USERNAME.lstrip('@')}")]
    ])


def payment_menu(order_id):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ I Have Paid", callback_data=f"paid:{order_id}")],
        [InlineKeyboardButton(text="❌ Cancel Order", callback_data=f"cancel:{order_id}")]
    ])


def admin_menu(order_id):
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Approve", callback_data=f"approve:{order_id}"),
            InlineKeyboardButton(text="❌ Reject", callback_data=f"reject:{order_id}")
        ]
    ])


async def send_qr(chat_id, order_id):
    caption = (
        f"📚 *{PRODUCT_NAME}*\n\n"
        f"💰 Amount: *₹{PRICE}*\n"
        f"🆔 Order ID: `{order_id}`\n\n"
        f"1. Scan the QR and pay exactly ₹{PRICE}.\n"
        f"2. UPI ID: `{UPI_ID}`\n"
        f"3. After payment, tap *I Have Paid*.\n"
        f"4. Enter your UTR / transaction reference number.\n\n"
        "⚠️ Delivery happens only after admin verifies the payment."
    )
    if QR_FILE.exists():
        await bot.send_photo(
            chat_id,
            FSInputFile(str(QR_FILE)),
            caption=caption,
            parse_mode="Markdown",
            reply_markup=payment_menu(order_id)
        )
    else:
        await bot.send_message(
            chat_id,
            caption,
            parse_mode="Markdown",
            reply_markup=payment_menu(order_id)
        )


@router.message(CommandStart())
async def start(message: Message):
    await message.answer(
        f"🚀 *{PRODUCT_NAME}*\n\n"
        f"💰 Price: ₹{PRICE}\n"
        "⚡ One-time payment\n"
        "📥 Manual payment verification + automatic delivery\n\n"
        "Choose an option:",
        parse_mode="Markdown",
        reply_markup=user_menu()
    )


@router.message(Command("buy"))
async def buy(message: Message):
    order_id = create_order(message.from_user.id, message.from_user.username)
    await send_qr(message.chat.id, order_id)


@router.callback_query(F.data == "buy")
async def buy_cb(callback: CallbackQuery):
    await callback.answer()
    order_id = create_order(callback.from_user.id, callback.from_user.username)
    await send_qr(callback.message.chat.id, order_id)


@router.callback_query(F.data == "details")
async def details(callback: CallbackQuery):
    await callback.answer()
    await callback.message.answer(
        f"📦 *{PRODUCT_NAME}*\n\n"
        "• Revision / mind-map material\n"
        "• Subject-wise study resources\n"
        "• PYQ material\n"
        "• Practice material\n\n"
        "Use only files that you own or are licensed to distribute.",
        parse_mode="Markdown",
        reply_markup=user_menu()
    )


@router.callback_query(F.data.startswith("paid:"))
async def paid_cb(callback: CallbackQuery):
    await callback.answer()
    order_id = callback.data.split(":", 1)[1]
    order = get_order(order_id)

    if not order or order["telegram_id"] != callback.from_user.id:
        await callback.message.answer("This order is not valid.")
        return

    if order["status"] != "awaiting_payment":
        await callback.message.answer("This order has already been submitted.")
        return

    await callback.message.answer(
        f"🧾 Order `{order_id}`\n\n"
        "Please send your UTR / transaction reference number in your next message.",
        parse_mode="Markdown"
    )


@router.callback_query(F.data.startswith("cancel:"))
async def cancel_cb(callback: CallbackQuery):
    await callback.answer()
    order_id = callback.data.split(":", 1)[1]
    order = get_order(order_id)
    if order and order["telegram_id"] == callback.from_user.id:
        set_status(order_id, "cancelled")
    await callback.message.answer("Order cancelled. You can start again with /buy.")


@router.message(F.text)
async def receive_utr(message: Message):
    # Ignore commands.
    if message.text.startswith("/"):
        return

    order = get_latest_pending(message.from_user.id)
    if not order:
        return

    utr = message.text.strip()
    if len(utr) < 4:
        await message.answer("Please send the UTR / transaction reference number.")
        return

    set_utr(order["order_id"], utr)

    admin_text = (
        "🔔 *New payment verification request*\n\n"
        f"🆔 Order: `{order['order_id']}`\n"
        f"👤 User: @{message.from_user.username or 'no_username'}\n"
        f"🆔 Telegram ID: `{message.from_user.id}`\n"
        f"💰 Amount: ₹{PRICE}\n"
        f"🔢 UTR: `{utr}`\n\n"
        "Verify the payment in your UPI app/bank, then approve or reject."
    )

    await bot.send_message(
        ADMIN_ID,
        admin_text,
        parse_mode="Markdown",
        reply_markup=admin_menu(order["order_id"])
    )
    await message.answer(
        "✅ Payment details submitted.\n\n"
        "Your order is waiting for verification. You'll receive the file after approval."
    )


@router.callback_query(F.data.startswith("approve:"))
async def approve_cb(callback: CallbackQuery):
    if callback.from_user.id != ADMIN_ID:
        await callback.answer("Not authorized.", show_alert=True)
        return

    await callback.answer()
    order_id = callback.data.split(":", 1)[1]
    order = get_order(order_id)
    if not order:
        await callback.message.answer("Order not found.")
        return

    if order["status"] == "approved":
        await callback.message.answer("Already approved.")
        return

    if not DELIVERY_FILE.exists():
        await callback.message.answer(
            f"❌ Delivery file missing: {DELIVERY_FILE}"
        )
        return

    set_status(order_id, "approved")

    await bot.send_message(
        order["telegram_id"],
        f"✅ *Payment verified!*\n\nHere is your {PRODUCT_NAME}.",
        parse_mode="Markdown"
    )
    await bot.send_document(
        order["telegram_id"],
        FSInputFile(str(DELIVERY_FILE)),
        caption="📚 Thank you for your purchase!"
    )

    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer(f"✅ Order {order_id} approved and delivered.")


@router.callback_query(F.data.startswith("reject:"))
async def reject_cb(callback: CallbackQuery):
    if callback.from_user.id != ADMIN_ID:
        await callback.answer("Not authorized.", show_alert=True)
        return

    await callback.answer()
    order_id = callback.data.split(":", 1)[1]
    order = get_order(order_id)
    if not order:
        return

    set_status(order_id, "rejected")
    await bot.send_message(
        order["telegram_id"],
        f"❌ Payment for order `{order_id}` could not be verified.\n\n"
        "Please contact support or submit a new payment.",
        parse_mode="Markdown"
    )
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer(f"❌ Order {order_id} rejected.")


async def main():
    init_db()
    await dp.start_polling(bot)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
